"""
    Abdul Samad
    24I-0095
    AI-B
"""
import sys
import random
import json
import os
import webbrowser
import time
from agents import Agent, Environment, TraceAgent

# Set seed for random values based on current time
random.seed(int(time.time() * 1000) + os.getpid())

class PuzzlePiece:
    # A single piece of the puzzle
    def __init__(self, correct_row, correct_col, orientation=0):
        self.correct_pos = (correct_row, correct_col)
        self.orientation = orientation

    def is_correctly_placed(self, current_pos):
        # Checks if piece is at the right spot and rotated correctly
        return self.correct_pos == current_pos and self.orientation == 0

    def rotate_left(self):
        self.orientation = (self.orientation + 90) % 360

    def rotate_right(self):
        self.orientation = (self.orientation - 90) % 360
        if self.orientation < 0:
            self.orientation += 360

    def deep_copy(self):
        return PuzzlePiece(self.correct_pos[0], self.correct_pos[1], self.orientation)

class JigsawEnvironment(Environment):
    # This environment manages the puzzle pieces on a grid
    def __init__(self, size=5, max_moves=100):
        super().__init__()
        self.size = size
        self.max_moves = max_moves
        self.steps_taken = 0
        self.history = []
        self.grid = [[None for _ in range(size)] for _ in range(size)]
        self._init_puzzle()

    def _init_puzzle(self):
        # Create pieces and shuffle them randomly
        pieces = []
        for r in range(self.size):
            for c in range(self.size):
                orientation = random.choice([0, 90, 180, 270])
                pieces.append(PuzzlePiece(r, c, orientation))
        random.shuffle(pieces)
        idx = 0
        for r in range(self.size):
            for c in range(self.size):
                self.grid[r][c] = pieces[idx]
                idx += 1

    def default_location(self, thing):
        return (random.randint(0, self.size - 1), random.randint(0, self.size - 1))

    def percept(self, agent):
        # Tells the agent about the piece at its current location
        r, c = agent.location
        piece = self.grid[r][c]
        is_holding = len(agent.holding) > 0
        return {
            'position': (r, c),
            'piece_id': piece.correct_pos,
            'orientation': piece.orientation,
            'is_correct': piece.is_correctly_placed((r, c)),
            'grid_size': self.size,
            'holding': is_holding
        }

    def execute_action(self, agent, action):
        # Updates the grid or agent based on the chosen action
        if self.steps_taken >= self.max_moves:
            return
        r, c = agent.location
        if action == 'Grab' and not agent.holding:
            agent.holding.append(True)
        elif action == 'Release' and agent.holding:
            agent.holding.pop()
        elif action == 'Left' and c > 0:
            if agent.holding:
                self.grid[r][c], self.grid[r][c - 1] = self.grid[r][c - 1], self.grid[r][c]
            agent.location = (r, c - 1)
        elif action == 'Right' and c < self.size - 1:
            if agent.holding:
                self.grid[r][c], self.grid[r][c + 1] = self.grid[r][c + 1], self.grid[r][c]
            agent.location = (r, c + 1)
        elif action == 'Up' and r > 0:
            if agent.holding:
                self.grid[r][c], self.grid[r - 1][c] = self.grid[r - 1][c], self.grid[r][c]
            agent.location = (r - 1, c)
        elif action == 'Down' and r < self.size - 1:
            if agent.holding:
                self.grid[r][c], self.grid[r + 1][c] = self.grid[r + 1][c], self.grid[r][c]
            agent.location = (r + 1, c)
        elif action == 'Rotate_left':
            self.grid[r][c].rotate_left()
        elif action == 'Rotate_right':
            self.grid[r][c].rotate_right()
        self.steps_taken += 1
        self.history.append({
            'action': action, 'agent_loc': agent.location,
            'holding': bool(agent.holding), 'grid': self.get_grid_state()
        })

    def get_grid_state(self):
        state = []
        for r in range(self.size):
            row = []
            for c in range(self.size):
                p = self.grid[r][c]
                row.append({'target': p.correct_pos, 'orientation': p.orientation})
            state.append(row)
        return state

    def is_done(self):
        return self.steps_taken >= self.max_moves or self.is_solved()

    def count_correct(self):
        # Counts how many pieces are in the right position and orientation
        count = 0
        for r in range(self.size):
            for c in range(self.size):
                if self.grid[r][c].is_correctly_placed((r, c)):
                    count += 1
        return count

    def is_solved(self):
        return self.count_correct() == self.size * self.size

    def performance(self):
        if self.steps_taken == 0: return 0.0
        return self.count_correct() / self.steps_taken

    def deep_copy(self):
        # Creates a fresh copy so both agents start with the same puzzle
        new_env = JigsawEnvironment.__new__(JigsawEnvironment)
        new_env.things, new_env.agents, new_env.history = [], [], []
        new_env.size, new_env.max_moves, new_env.steps_taken = self.size, self.max_moves, 0
        new_env.grid = [[None] * self.size for _ in range(self.size)]
        for r in range(self.size):
            for c in range(self.size):
                new_env.grid[r][c] = self.grid[r][c].deep_copy()
        return new_env

    def print_state(self, title="Puzzle State"):
        # Prints out the current state of the puzzle grid
        print(f"\n{'=' * 60}")
        print(f"  {title}")
        print(f"{'=' * 60}")
        print(f"  Grid Size     : {self.size} x {self.size}")
        print(f"  Correct Pieces: {self.count_correct()} / {self.size * self.size}")
        print(f"  Moves Used    : {self.steps_taken}")

        if self.size <= 8:
            # Show the full grid if it's small enough to read
            print(f"\n  Legend: [target_pos | rotation, C=correct X=wrong]")
            for r in range(self.size):
                row_str = "  "
                for c in range(self.size):
                    p = self.grid[r][c]
                    mark = "C" if p.is_correctly_placed((r, c)) else "X"
                    row_str += f"[({p.correct_pos[0]},{p.correct_pos[1]}){p.orientation:>4}{mark}] "
                print(row_str)
        else:
            # Show just a corner for larger puzzles to save space
            corner = min(5, self.size)
            print(f"\n  Top-left {corner}x{corner} corner preview:")
            for r in range(corner):
                row_str = "  "
                for c in range(corner):
                    p = self.grid[r][c]
                    mark = "C" if p.is_correctly_placed((r, c)) else "X"
                    row_str += f"[({p.correct_pos[0]:>2},{p.correct_pos[1]:>2}){p.orientation:>4}{mark}] "
                print(row_str)
            print("  ...")
        print(f"{'=' * 60}")

def simple_reflex_program(percept):
    # A simple agent that only looks at the current piece
    pos = percept['position']
    piece_id = percept['piece_id']
    orientation = percept['orientation']
    is_correct = percept['is_correct']
    grid_size = percept['grid_size']
    holding = percept['holding']
    r, c = pos
    target_r, target_c = piece_id

    if holding:
        if (r, c) == (target_r, target_c):
            if orientation == 0: return 'Release'
            return 'Rotate_left' if orientation == 270 else 'Rotate_right'
        dr = target_r - r
        dc = target_c - c
        if abs(dr) >= abs(dc): return 'Down' if dr > 0 else 'Up'
        return 'Right' if dc > 0 else 'Left'
    else:
        if not is_correct: return 'Grab'
        if c < grid_size - 1: return 'Right'
        if r < grid_size - 1: return 'Down'
        if c > 0: return 'Left'
        if r > 0: return 'Up'
        return 'NoOp'

class ModelBasedReflexProgram:
    # An agent that remembers what it has seen to make better choices
    def __init__(self, grid_size):
        self.grid_size = grid_size
        self.model = [[None] * grid_size for _ in range(grid_size)]
        self.correct_cells = set()
        self.last_actions = []

    def __call__(self, percept):
        pos = percept['position']
        piece_id = percept['piece_id']
        orientation = percept['orientation']
        is_correct = percept['is_correct']
        holding = percept['holding']
        r, c = pos
        self.model[r][c] = {'piece_id': piece_id, 'orientation': orientation}
        if is_correct: self.correct_cells.add((r, c))
        else: self.correct_cells.discard((r, c))

        if holding:
            tr, tc = piece_id
            if (r, c) == (tr, tc):
                if orientation == 0: return self._record('Release')
                return self._record('Rotate_left' if orientation == 270 else 'Rotate_right')
            return self._move_to(r, c, tr, tc, True)
        else:
            if not is_correct: return self._record('Grab')
            best = self._find_wrong_piece(r, c)
            if best: return self._move_to(r, c, best[0], best[1], False)
            return self._explore(r, c)

    def _find_wrong_piece(self, r, c):
        best_pos, min_dist = None, float('inf')
        for vr in range(self.grid_size):
            for vc in range(self.grid_size):
                if (vr, vc) not in self.correct_cells and self.model[vr][vc]:
                    dist = abs(vr - r) + abs(vc - c)
                    if dist < min_dist: min_dist, best_pos = dist, (vr, vc)
        return best_pos

    def _move_to(self, r, c, tr, tc, holding):
        dr, dc = tr - r, tc - c
        moves = []
        if abs(dr) >= abs(dc):
            moves.extend(['Down' if dr > 0 else 'Up', 'Right' if dc > 0 else 'Left'])
        else:
            moves.extend(['Right' if dc > 0 else 'Left', 'Down' if dr > 0 else 'Up'])
        for a in moves:
            nr, nc = r, c
            if a == 'Up': nr -= 1
            elif a == 'Down': nr += 1
            elif a == 'Left': nc -= 1
            elif a == 'Right': nc += 1
            if 0 <= nr < self.grid_size and 0 <= nc < self.grid_size:
                if not self._loops(a) and not (holding and (nr, nc) in self.correct_cells):
                    return self._record(a)
        return self._record('NoOp')

    def _explore(self, r, c):
        for a in ['Right', 'Down', 'Left', 'Up']:
            nr, nc = r, c
            if a == 'Up': nr -= 1
            elif a == 'Down': nr += 1
            elif a == 'Left': nc -= 1
            elif a == 'Right': nc += 1
            if 0 <= nr < self.grid_size and 0 <= nc < self.grid_size and not self._loops(a):
                return self._record(a)
        return self._record('NoOp')

    def _loops(self, action):
        ops = {'Left':'Right', 'Right':'Left', 'Up':'Down', 'Down':'Up'}
        if len(self.last_actions) >= 2:
            return self.last_actions[-1] == ops.get(action) and self.last_actions[-2] == action
        return False

    def _record(self, action):
        self.last_actions.append(action)
        if len(self.last_actions) > 10: self.last_actions.pop(0)
        return action

def main():
    viz = "--viz" in sys.argv
    if viz: sys.argv.remove("--viz")
    size = int(sys.argv[1]) if len(sys.argv) >= 2 else 3
    max_moves = int(sys.argv[2]) if len(sys.argv) >= 3 else 50
    env = JigsawEnvironment(size, max_moves)
    start_pos = env.default_location(None)
    e_reflex, e_model = env.deep_copy(), env.deep_copy()
    
    print("Starting Comparison")
    r_agent = TraceAgent(Agent(simple_reflex_program))
    e_reflex.add_thing(r_agent, location=start_pos)
    e_reflex.run()
    e_reflex.print_state("Simple Reflex Results")

    m_agent = TraceAgent(Agent(ModelBasedReflexProgram(size)))
    e_model.add_thing(m_agent, location=start_pos)
    e_model.run()
    e_model.print_state("Model-Based Results")

    # Show the results for both agents side-by-side
    res_reflex = e_reflex.performance()
    res_model = e_model.performance()

    print(f"\n{'=' * 60}")
    print(f"  PERFORMANCE COMPARISON")
    print(f"{'=' * 60}")
    print(f"  Reflex Agent      : No of correct pieces = {e_reflex.count_correct()}, no of moves utilized = {e_reflex.steps_taken}")
    print(f"  Model-based Agent : No of correct pieces = {e_model.count_correct()}, no of moves utilized = {e_model.steps_taken}")
    print(f"\n  Reflex Agent Performance      : {res_reflex:.4f}")
    print(f"  Model-based Agent Performance : {res_model:.4f}")
    print(f"{'=' * 60}\n")

    if viz:
        replay_data = {
            'timestamp': time.strftime("%Y-%m-%d %H:%M:%S"),
            'grid_size': size,
            'max_moves': max_moves,
            'reflex': {'history': e_reflex.history, 'correct': e_reflex.count_correct()},
            'model': {'history': e_model.history, 'correct': e_model.count_correct()}
        }
        
        # Use index.html as a template for replay.html
        base_dir = os.path.dirname(os.path.abspath(__file__))
        template_path = os.path.join(base_dir, 'viz', 'index.html')
        output_path = os.path.join(base_dir, 'viz', 'replay.html')

        if os.path.exists(template_path):
            with open(template_path, 'r') as f:
                content = f.read()
            
            data_script = f"<script id='replay-data'>window.REPLAY_DATA = {json.dumps(replay_data, indent=2)};</script>"
            new_content = content.replace("<!-- DATA_PLACEHOLDER -->", data_script)
            
            with open(output_path, 'w') as f:
                f.write(new_content)
            
            print(f"Visualization saved to {output_path}")
            webbrowser.open(f"file://{os.path.abspath(output_path)}")
        else:
            print(f"Error: Visualizer template not found at {template_path}")

if __name__ == "__main__":
    main()
